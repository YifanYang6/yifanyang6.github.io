## .latexmkrc — local PDF build for the ICSE 2027 IEEE paper
##
## Quick reference:
##   latexmk            build main_icse2027.pdf (pdflatex → bibtex → pdflatex×2 as needed)
##   latexmk -pvc       continuous mode: rebuild + refresh viewer on every save
##   latexmk -c         clean aux files, KEEP the PDF
##   latexmk -C         clean everything INCLUDING the PDF
##
## Engine: pdflatex (IEEEtran is fine with pdflatex; no shell-escape needed —
## the paper uses listings/tikz/pgfplots, not minted or tikzexternalize).

$pdf_mode   = 1;          # produce PDF directly via pdflatex
$bibtex_use = 2;          # run bibtex when needed; keep the .bbl

$pdflatex = 'pdflatex -interaction=nonstopmode -file-line-error -synctex=1 %O %S';

@default_files = ('main_icse2027.tex');

# Also remove these on `latexmk -c` (the rest are covered by latexmk defaults / .gitignore)
$clean_ext = 'synctex.gz synctex(busy) bbl run.xml';
