# Eval DB export — 8 in-scope experiments (2026-06-08)

Snapshot of `evaluation_data` rows for the 8 experiments used in the paper:
6 frameworks × base model (thinkdepthai has 2: sonnet-4.6 + qwen3.5-plus), i.e.
7 baselines + 1 treatment. **4000 rows total.**

Source: `postgresql://localhost:5433/SOTA`, table `evaluation_data`.
The treatment (`thinkdepthai-qwen3.5-plus-12cat-coding`) reflects the applied
trajectory-graph fallback re-grade (AC **87.6%**, was 86.4%).

## Files
| file | tracked in git? | purpose |
|---|---|---|
| `evaluation_data_8exp.copy.sql.gz` | **no** (89 MB, see `.gitignore`) | re-importable data dump (Postgres COPY format, gzipped) |
| `schema.sql` | yes | best-effort `CREATE TABLE evaluation_data` for a fresh DB |
| `manifest.json` | yes | exp list, per-exp row counts + AC, columns, sha256, timestamp |
| `.gitignore` | yes | excludes the 89 MB dump from git |

## Per-experiment accuracy (from `correct`)
| exp_id | rows | AC |
|---|---|---|
| thinkdepthai-qwen3.5-plus | 500 | 79.0% |
| thinkdepthai-claude-sonnet-4.6 | 500 | 89.8% |
| aiq-qwen3.5-plus | 500 | 77.4% |
| taskweaver-qwen3.5-plus | 500 | 59.6% |
| claudecode-qwen3.5-plus | 500 | 79.4% |
| openrca-qwen3.5-plus | 500 | 46.4% |
| mabc-qwen3.5-plus | 500 | 42.6% |
| **thinkdepthai-qwen3.5-plus-12cat-coding** (treatment) | 500 | **87.6%** |

## Re-import onto another machine / server

```bash
# 1. (fresh DB only) create the table:
psql "$TARGET_DB_URL" -f schema.sql

# 2. load the rows (rows carry their original `id`; load into an empty
#    evaluation_data or one without these 8 exp_ids to avoid PK conflicts):
gunzip -c evaluation_data_8exp.copy.sql.gz | psql "$TARGET_DB_URL"
```

To replace only these 8 experiments on a target that already has them:
```bash
psql "$TARGET_DB_URL" -c "DELETE FROM evaluation_data WHERE exp_id IN (
  'thinkdepthai-qwen3.5-plus','thinkdepthai-claude-sonnet-4.6','aiq-qwen3.5-plus',
  'taskweaver-qwen3.5-plus','claudecode-qwen3.5-plus','openrca-qwen3.5-plus',
  'mabc-qwen3.5-plus','thinkdepthai-qwen3.5-plus-12cat-coding');"
gunzip -c evaluation_data_8exp.copy.sql.gz | psql "$TARGET_DB_URL"
```

Verify checksum before importing: `sha256sum evaluation_data_8exp.copy.sql.gz` should match `dump_sha256` in `manifest.json`.
