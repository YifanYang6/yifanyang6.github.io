#!/usr/bin/env python3
"""Generate generated/rq2_ngram_n5.json for the RQ2 5-gram move-loop figure.

Recomputes, per experiment, the mean per-trajectory overlapping count of every
contiguous 5-move pattern (sliding windows), keeping a pattern iff its max value
over the experiments is >= 0.5/traj. Source: /tmp/rq2_substrate.json (per-traj
ordered `moves`). Denominator = trajectories with >=1 move (matches n_traj).

This is the persistent generator for the artifact the lost one-off produced; it
keeps only the two ThinkDepth.ai arms used in the paper figure.

  python figures/gen_rq2_ngram_n5.py   ->   generated/rq2_ngram_n5.json
"""
import json
import os
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = "/tmp/rq2_substrate.json"
OUT = os.path.join(HERE, os.pardir, "generated", "rq2_ngram_n5.json")
N = 5
THRESH = 0.5

EXP_SHORT = [
    ("thinkdepthai-claude-sonnet-4.6",          "TD-sonnet"),
    ("thinkdepthai-qwen3.5-plus",               "TD-qwen"),
]
SHORT = {"symptom_scan": "Sym", "log_inspect": "Log", "keyword_search": "Kw",
         "service_enum": "Svc", "metric_enum": "Menm", "trace_follow": "Trc",
         "callgraph": "Cg", "network_flow": "Net", "resource_probe": "Rp",
         "metric_dump": "Mdmp", "lifecycle_probe": "Life"}


def main():
    data = json.load(open(SRC))
    present = [(eid, short) for eid, short in EXP_SHORT if eid in data]
    order = [short for _, short in present]

    means = {}      # short -> {ngram_tuple: mean per-traj overlapping count}
    n_traj = {}
    for eid, short in present:
        totals = defaultdict(float)
        nt = 0
        for r in data[eid]:
            moves = r.get("moves") or []
            if not moves:
                continue
            nt += 1
            for i in range(len(moves) - N + 1):
                totals[tuple(moves[i:i + N])] += 1
        n_traj[short] = nt
        means[short] = {ng: c / nt for ng, c in totals.items()} if nt else {}

    all_ng = set().union(*[set(m) for m in means.values()]) if means else set()
    patterns = []
    for ng in all_ng:
        vals = {short: means[short].get(ng, 0.0) for short in order}
        if max(vals.values()) >= THRESH:
            patterns.append({
                "ngram": list(ng),
                "label": "·".join(SHORT.get(m, m) for m in ng),
                "values": vals,
            })
    # ascending by max value so the strongest pattern sits at the top of the barh
    patterns.sort(key=lambda p: max(p["values"].values()))

    out = {
        "n": N,
        "experiments": order,
        "n_traj": n_traj,
        "patterns": patterns,
        "keep_rule": f"max per-traj overlapping count over {len(order)} exps >= {THRESH}",
        "source": SRC,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    json.dump(out, open(OUT, "w"), indent=1, ensure_ascii=False)
    print(f"wrote {OUT}: {len(patterns)} patterns over {len(order)} experiments "
          f"({', '.join(order)})")


if __name__ == "__main__":
    main()
