#!/usr/bin/env python3
"""RQ2 per-experiment *move-stream* figures: the share of each of the 11 SRE
move-types across normalized trajectory progress, ONE stacked-area chart per
experiment (mimics the multimodal "action-over-progress" stream chart in the
SWE-agent literature; see the user's reference figure).

Pipeline (exactly as requested):
  1. For each trajectory, place its move at index i (of n) at progress p=i/n,
     bin into N_BINS phases; within each phase compute that trajectory's per-move
     SHARE (proportion of the phase's moves that are each type).
  2. MACRO-average each phase share over the ~500 cases that touch the phase
     (every trajectory equal weight -- matches RQ2's macro stance).
  3. Re-normalize every phase column to sum to exactly 1 (relative frequency),
     so all experiments share one 0-1 scale and are directly comparable.

Colors are UNIFIED across all experiments and follow the canonical SRE
investigation funnel from shallow to deep: Symptom(detect) -> Inventory(orient)
-> Topology(localize) -> Resource(drill) -> Liveness(confirm).

Outputs:
  figures/rq2_move_stream_<short>.{pdf,png}   -- 5 standalone figures
  figures/rq2_move_stream_combined.{pdf,png}  -- 1x5 two-column panel (figure*)
  generated/rq2_move_stream.json              -- data + provenance

Source of truth: /tmp/rq2_substrate.json (per-traj ordered `moves`, SQL-only,
discovery+schema-peek excluded -- regenerate from the *peekfixed* step_cache via
  /home/nn/SOTA-agents/RCAgentEval/.venv/bin/python /tmp/rq2_extract_substrate.py
Run this script with the RCA venv (matplotlib):
  /home/nn/SOTA-agents/RCAgentEval/.venv/bin/python figures/render_rq2_move_stream.py
"""
import json
import os
from collections import Counter, defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.colors import to_rgb
from matplotlib.patches import Patch

SRC = "/tmp/rq2_substrate.json"
HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DATA = os.path.join(HERE, os.pardir, "generated", "rq2_move_stream.json")

N_BINS = 20

# Experiments: two ThinkDepth.ai peers first (cross-base contrast), then the other
# three qwen frameworks. (short_id, display title, compact panel title)
EXPERIMENTS = [
    ("thinkdepthai-qwen3.5-plus",       "td_qwen",     "ThinkDepth.ai (Qwen3.5-Plus)",        r"$\mathrm{TD}_{\mathrm{qwen}}$"),
    ("thinkdepthai-claude-sonnet-4.6",  "td_sonnet",   "ThinkDepth.ai (Claude-Sonnet-4.6)",   r"$\mathrm{TD}_{\mathrm{sonnet}}$"),
    ("claudecode-qwen3.5-plus",         "claudecode",  "ClaudeCode (Qwen3.5-Plus)",        "ClaudeCode"),
    ("aiq-qwen3.5-plus",                "aiq",         "AIQ (Qwen3.5-Plus)",               "AIQ"),
    ("taskweaver-qwen3.5-plus",         "taskweaver",  "TaskWeaver (Qwen3.5-Plus)",        "TaskWeaver"),
]

# 11 moves grouped by SRE family; bottom->top = shallow -> deep investigation.
FAMILIES = [
    ("Symptom",   [("symptom_scan",    "#B8B8E6"),
                   ("log_inspect",     "#D9D9D9"),
                   ("keyword_search",  "#80B1D3")]),
    ("Inventory", [("service_enum",    "#8DD3C7"),
                   ("metric_enum",     "#80B1D3")]),
    ("Topology",  [("trace_follow",    "#FDB462"),
                   ("callgraph",       "#B3DE69"),
                   ("network_flow",    "#FFFFB3")]),
    ("Resource",  [("resource_probe",  "#FB8072"),
                   ("metric_dump",     "#FCCDE5")]),
    ("Liveness",  [("lifecycle_probe", "#CCEBC5")]),
]
MOVES = [m for _, fam in FAMILIES for m, _ in fam]          # bottom -> top
COLORS = {m: c for _, fam in FAMILIES for m, c in fam}
MOVE_FAMILY = {m: fname for fname, fam in FAMILIES for m, _ in fam}


def _text_color(hex_color):
    """Black or white text for max contrast on the given band color."""
    r, g, b = to_rgb(hex_color)
    lum = 0.2126 * r + 0.7152 * g + 0.0722 * b           # relative luminance
    return ("black", "white") if lum > 0.55 else ("white", "black")


def macro_progression(trajs):
    """Per-phase MACRO move-share, re-normalized to sum to 1 per phase.

    Returns (shares[move] -> [N_BINS] fractions, extras)."""
    bin_sum = [defaultdict(float) for _ in range(N_BINS)]   # sum over trajs of per-traj share
    bin_traj = [0] * N_BINS                                 # # trajs touching the bin
    move_lens = []
    for r in trajs:
        moves = r["moves"]
        n = len(moves)
        if n == 0:
            continue
        move_lens.append(n)
        per_bin_cnt = [Counter() for _ in range(N_BINS)]
        per_bin_tot = [0] * N_BINS
        for i, mv in enumerate(moves):
            b = min(int((i / n) * N_BINS), N_BINS - 1)
            per_bin_cnt[b][mv] += 1
            per_bin_tot[b] += 1
        for b in range(N_BINS):
            if per_bin_tot[b] > 0:
                bin_traj[b] += 1
                for mv in MOVES:
                    if per_bin_cnt[b].get(mv):
                        bin_sum[b][mv] += per_bin_cnt[b][mv] / per_bin_tot[b]

    shares = {mv: [(bin_sum[b][mv] / bin_traj[b]) if bin_traj[b] else 0.0
                   for b in range(N_BINS)] for mv in MOVES}
    # explicit re-normalization: each phase column sums to exactly 1.0
    for b in range(N_BINS):
        tot = sum(shares[mv][b] for mv in MOVES)
        if tot > 0:
            for mv in MOVES:
                shares[mv][b] /= tot
    # overall share = mean band height over phases (macro over progress)
    mean_share = {mv: (sum(shares[mv]) / N_BINS) for mv in MOVES}

    def _median(xs):
        if not xs:
            return None
        xs = sorted(xs)
        k = len(xs)
        return xs[k // 2] if k % 2 else 0.5 * (xs[k // 2 - 1] + xs[k // 2])

    extras = {
        "n_traj": len([r for r in trajs if r["moves"]]),
        "median_moves": _median(move_lens),
        "mean_share": mean_share,
    }
    return shares, extras


def _cum_bottom(shares):
    """cumulative bottom edge of each band per bin (bottom->top stacking)."""
    cum = [0.0] * N_BINS
    bottoms = {}
    for mv in MOVES:
        bottoms[mv] = list(cum)
        for b in range(N_BINS):
            cum[b] += shares[mv][b]
    return bottoms


def _band_labels(ax, x, shares, mean_share, *, thresh, fontsize, with_name, min_gap):
    """Label every band whose overall share >= thresh, at the phase where the band
    is widest, with greedy vertical de-collision within each x-cluster. with_name:
    "move (X%)" vs bare "X%". Bands too thin to host text fall back to a leader dot."""
    bottoms = _cum_bottom(shares)
    cands = []
    for mv in MOVES:
        ms = mean_share[mv]
        if ms < thresh:
            continue
        b = max(range(N_BINS), key=lambda j: shares[mv][j])      # widest phase
        h = shares[mv][b]
        cands.append({"mv": mv, "x": x[b], "y": bottoms[mv][b] + h / 2, "ms": ms, "h": h})
    # de-collide: cluster by x proximity, then push apart vertically by min_gap
    clusters = []
    for c in sorted(cands, key=lambda c: c["x"]):
        for cl in clusters:
            if abs(cl[-1]["x"] - c["x"]) < 0.16:
                cl.append(c)
                break
        else:
            clusters.append([c])
    for cl in clusters:
        cl.sort(key=lambda c: c["y"])
        for i in range(1, len(cl)):
            if cl[i]["y"] - cl[i - 1]["y"] < min_gap:
                cl[i]["y"] = cl[i - 1]["y"] + min_gap
    for c in cands:
        c["y"] = min(max(c["y"], 0.03), 0.97)
        fg, stroke = _text_color(COLORS[c["mv"]])
        txt = f"{c['mv']} ({c['ms']*100:.0f}%)" if with_name else f"{c['ms']*100:.0f}%"
        # edge-aware anchoring so labels at the far left/right stay inside the axes
        if c["x"] >= 0.84:
            ha, xpos = "right", min(c["x"], 0.985)
        elif c["x"] <= 0.16:
            ha, xpos = "left", max(c["x"], 0.015)
        else:
            ha, xpos = "center", c["x"]
        ax.text(xpos, c["y"], txt, fontsize=fontsize, ha=ha, va="center",
                color=fg, linespacing=0.9, zorder=5,
                path_effects=[pe.withStroke(linewidth=1.3, foreground=stroke)])


def draw_stream(ax, x, shares, extras, *, label_thresh, label_fs,
                with_name=True, min_gap=0.058):
    ys = [shares[mv] for mv in MOVES]                       # fractions, bottom->top
    ax.stackplot(x, *ys, colors=[COLORS[mv] for mv in MOVES],
                 edgecolor="white", linewidth=0.2)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    if label_thresh <= 1.0:
        _band_labels(ax, x, shares, extras["mean_share"], thresh=label_thresh,
                     fontsize=label_fs, with_name=with_name, min_gap=min_gap)


def family_legend_handles(mean_share=None):
    """Patches in family order (shades cluster). If mean_share given, append the
    per-move overall share so every band's % is readable even when not labeled inline."""
    out = []
    for mv in MOVES:
        lab = mv if mean_share is None else f"{mv}  ({mean_share[mv]*100:.0f}%)"
        out.append(Patch(fc=COLORS[mv], ec="white", lw=0.3, label=lab))
    return out


def render_standalone(eid, short, title, shares, extras, x):
    fig, ax = plt.subplots(figsize=(7.0, 3.5))
    # attachment style: every band (>=1.8%) labeled inline "move (X%)" -- no legend.
    draw_stream(ax, x, shares, extras, label_thresh=0.018, label_fs=7.4,
                with_name=True, min_gap=0.06)
    ax.set_xlabel("Normalized progress", fontsize=10, labelpad=2)
    ax.set_ylabel("Relative frequency", fontsize=10, labelpad=2)
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.tick_params(labelsize=8, length=2.5, pad=1.5)
    ax.set_title(title, fontsize=11, pad=4)
    ax.text(0.985, 0.025, f"median {int(extras['median_moves'])} moves",
            transform=ax.transAxes, fontsize=7.5, ha="right", va="bottom", color="white",
            path_effects=[pe.withStroke(linewidth=1.3, foreground="#00000099")])
    fig.subplots_adjust(left=0.082, right=0.985, top=0.91, bottom=0.12)
    base = os.path.join(HERE, f"rq2_move_stream_{short}")
    fig.savefig(base + ".pdf")
    fig.savefig(base + ".png", dpi=200)
    plt.close(fig)
    print("wrote", base + ".pdf/.png")


def render_combined(all_shares, all_extras, x):
    fig, axes = plt.subplots(1, len(EXPERIMENTS), figsize=(7.16, 2.25), sharey=True)
    for ax, (eid, short, _title, panel) in zip(axes, EXPERIMENTS):
        shares, extras = all_shares[eid], all_extras[eid]
        # narrow panels: no inline callouts (text wider than panel) -- the shared
        # top legend decodes every band; the standalone figures carry the % callouts.
        draw_stream(ax, x, shares, extras, label_thresh=5.0, label_fs=5.0, pretty=False)
        ax.set_xticks([0, 0.5, 1.0])
        ax.set_yticks([0, 0.5, 1.0])
        ax.tick_params(labelsize=6, length=2, pad=1.5)
        ax.set_title(panel, fontsize=8, pad=2.5)
        ax.set_xlabel("Norm. progress", fontsize=6.8, labelpad=1.5)
        ax.text(0.97, 0.03, f"n={extras['n_traj']}, {int(extras['median_moves'])} mv",
                transform=ax.transAxes, fontsize=5.0, ha="right", va="bottom", color="white",
                path_effects=[pe.withStroke(linewidth=1.0, foreground="#00000088")])
    axes[0].set_ylabel("Relative frequency", fontsize=7.5, labelpad=1)
    handles = family_legend_handles()
    fig.legend(handles=handles, loc="upper center", ncol=6, fontsize=6.2, frameon=False,
               handlelength=1.0, handleheight=0.9, columnspacing=1.0, handletextpad=0.4,
               borderpad=0.1, bbox_to_anchor=(0.5, 1.008))
    fig.subplots_adjust(left=0.062, right=0.992, top=0.78, bottom=0.135, wspace=0.08)
    base = os.path.join(HERE, "rq2_move_stream_combined")
    fig.savefig(base + ".pdf")
    fig.savefig(base + ".png", dpi=220)
    plt.close(fig)
    print("wrote", base + ".pdf/.png")


# Experiment palette, matched to the RQ2 n-gram figure (figures/render_rq2_ngram_n5.py)
# so the two RQ2 figures read consistently:
#   sonnet base = warm orange; the four qwen frameworks = Blues dark->light by AC@1
#   (ClaudeCode > TD-qwen > AIQ > TaskWeaver); the qwen TREATMENT = green.
EXP_COLORS = {
    "thinkdepthai-claude-sonnet-4.6":         "#D96B2B",     # sonnet base = muted orange
    "claudecode-qwen3.5-plus":                "#2F5597",     # qwen frameworks, readable blue shades
    "thinkdepthai-qwen3.5-plus":              "#4878CF",
    "aiq-qwen3.5-plus":                       "#5F8DBE",
    "taskweaver-qwen3.5-plus":                "#6B8FB5",
}
EXP_DISP = {
    "thinkdepthai-qwen3.5-plus":      r"ThinkDepth.ai$\cdot$Qwen",
    "thinkdepthai-claude-sonnet-4.6": r"ThinkDepth.ai$\cdot$Sonnet",
    "claudecode-qwen3.5-plus":        "ClaudeCode",
    "aiq-qwen3.5-plus":               "AIQ",
    "taskweaver-qwen3.5-plus":        "TaskWeaver",
}
def render_grid(all_shares, all_extras, x):
    fig = plt.figure(figsize=(6.2, 2.75))
    # Single-row grid: the two ThinkDepth.ai peers (the sonnet-base run and the
    # qwen baseline).
    gs = fig.add_gridspec(1, 2, left=0.08, right=0.995, top=0.74, bottom=0.16,
                          wspace=0.28)
    GRID_POS = {
        "thinkdepthai-claude-sonnet-4.6":         (0, 0),   # sonnet-base run
        "thinkdepthai-qwen3.5-plus":              (0, 1),   # qwen baseline
    }

    for eid in GRID_POS:
        r, c = GRID_POS[eid]
        ax = fig.add_subplot(gs[r, c])
        # small panels: bare "X%" on bands >=5% (names via the top move legend)
        draw_stream(ax, x, all_shares[eid], all_extras[eid], label_thresh=0.05,
                    label_fs=5.4, with_name=False, min_gap=0.105)
        ax.set_xticks([0, 0.5, 1.0])
        ax.set_yticks([0, 0.5, 1.0])
        ax.tick_params(labelsize=6, length=2, pad=1.5)
        ax.set_title(EXP_DISP[eid], color=EXP_COLORS[eid], fontsize=8.5, pad=2.5, fontweight="bold")
        ax.set_xlabel("Norm. progress", fontsize=6.6, labelpad=1)
        if c == 0:
            ax.set_ylabel("Rel. freq.", fontsize=7, labelpad=1)
        e = all_extras[eid]
        ax.text(0.97, 0.035, f"med {int(e['median_moves'])} mv",
                transform=ax.transAxes, fontsize=5.4, ha="right", va="bottom", color="white",
                path_effects=[pe.withStroke(linewidth=1.0, foreground="#00000099")])
    # TOP legend: 11 moves, family order (decodes the stream bands)
    move_handles = family_legend_handles()
    fig.legend(handles=move_handles, loc="upper center", ncol=6, fontsize=6.4, frameon=False,
               handlelength=1.0, handleheight=0.9, columnspacing=1.0, handletextpad=0.4,
               bbox_to_anchor=(0.5, 1.005), title="Move type (stream bands)", title_fontsize=6.8)
    base = os.path.join(HERE, "rq2_move_stream_grid")
    fig.savefig(base + ".pdf", bbox_inches="tight")
    fig.savefig(base + ".png", dpi=220, bbox_inches="tight")
    plt.close(fig)
    print("wrote", base + ".pdf/.png")


def main():
    data = json.load(open(SRC))
    x = [(b + 0.5) / N_BINS for b in range(N_BINS)]        # phase centers (fraction)

    all_shares, all_extras = {}, {}
    provenance = {
        "source": SRC,
        "estimator": "per-trajectory macro move-share over normalized progress, "
                     "re-normalized per phase to sum to 1 (relative frequency)",
        "n_bins": N_BINS,
        "stacking_order_bottom_to_top": MOVES,
        "move_family": MOVE_FAMILY,
        "colors": COLORS,
        "phase_centers": x,
        "experiments": {},
    }
    for eid, short, title, _panel in EXPERIMENTS:
        shares, extras = macro_progression(data[eid])
        all_shares[eid], all_extras[eid] = shares, extras
        render_standalone(eid, short, title, shares, extras, x)
        provenance["experiments"][eid] = {
            "short": short, "title": title,
            "n_traj": extras["n_traj"], "median_moves": extras["median_moves"],
            "shares": {mv: [round(s, 5) for s in shares[mv]] for mv in MOVES},
            "mean_share_pct": {mv: round(extras["mean_share"][mv] * 100, 3) for mv in MOVES},
        }

    render_grid(all_shares, all_extras, x)

    os.makedirs(os.path.dirname(OUT_DATA), exist_ok=True)
    json.dump(provenance, open(OUT_DATA, "w"), indent=1, ensure_ascii=False)
    print("wrote", OUT_DATA)


if __name__ == "__main__":
    main()
