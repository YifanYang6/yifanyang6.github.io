#!/usr/bin/env python3
"""RQ2 combined 5-gram figure for the two ThinkDepth.ai arms.

Two arms on one grouped horizontal bar chart. Metric = mean
occurrences per trajectory of each contiguous 5-move pattern (overlapping
sliding windows). Patterns kept iff >= 0.5/traj in at least one experiment.
Source data: generated/rq2_ngram_n5.json (recomputed from /tmp/rq2_substrate.json).
"""
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

HERE = __file__.rsplit("/", 1)[0]
DATA = f"{HERE}/../generated/rq2_ngram_n5.json"
OUT_PDF = f"{HERE}/rq2_ngram_n5.pdf"
OUT_PNG = f"{HERE}/rq2_ngram_n5.png"

# top -> bottom order within each pattern group; offsets go + (top) to - (bottom)
PLOT_ORDER = ["TD-sonnet", "TD-qwen"]
COLORS = {
    "TD-sonnet": "#DD8452",
    "TD-qwen": "#4C72B0",
}
LEGEND = {
    "TD-sonnet": "TD-sonnet  (sonnet base)",
    "TD-qwen": "TD-qwen  (qwen)",
}
SHORT = {"symptom_scan": "Sym", "log_inspect": "Log", "keyword_search": "Kw",
         "service_enum": "Svc", "metric_enum": "Menm", "trace_follow": "Trc",
         "callgraph": "Cg", "network_flow": "Net", "resource_probe": "Rp",
         "metric_dump": "Mdmp", "lifecycle_probe": "Life"}


def label_for(ngram):
    if len(set(ngram)) == 1:
        return f"{SHORT[ngram[0]]} ×5"      # pure loop -> Sym x5
    return "·".join(SHORT[m] for m in ngram)  # mixed -> Sym·Log·...


def main():
    d = json.load(open(DATA))
    pats = d["patterns"]
    # order patterns ascending by max so the strongest sits at TOP of the barh
    pats = sorted(pats, key=lambda p: max(p["values"].values()))
    labels = [label_for(p["ngram"]) for p in pats]
    n_groups = len(pats)
    n_bars = len(PLOT_ORDER)
    bh = 0.15
    offsets = [((n_bars - 1) / 2 - i) * bh for i in range(n_bars)]  # + at top

    plt.rcParams["font.family"] = "DejaVu Sans"
    fig, ax = plt.subplots(figsize=(7.2, 2.7))

    for i, exp in enumerate(PLOT_ORDER):
        ys = [g + offsets[i] for g in range(n_groups)]
        xs = [p["values"][exp] for p in pats]
        ax.barh(ys, xs, height=bh, color=COLORS[exp], edgecolor="white",
                linewidth=0.3, zorder=3)
        for y, x in zip(ys, xs):
            if x >= 0.30:  # annotate only the salient signatures, keep it clean
                ax.text(x + 0.012, y, f"{x:.2f}", va="center", ha="left",
                        fontsize=5.6, color="#334155", zorder=4)

    ax.set_yticks(range(n_groups))
    ax.set_yticklabels(labels, fontsize=8, family="monospace")
    ax.set_ylim(-0.6, n_groups - 0.4)
    ax.set_xlim(0, max(max(p["values"].values()) for p in pats) * 1.12)
    ax.set_xlabel("mean occurrences per trajectory  (overlapping 5-grams)",
                  fontsize=8.5, labelpad=3)
    ax.grid(axis="x", color="#e2e8f0", linewidth=0.6, zorder=0)
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color("#94a3b8")
    ax.tick_params(axis="both", length=0)

    handles = [Patch(facecolor=COLORS[e], edgecolor="white", label=LEGEND[e])
               for e in PLOT_ORDER]
    ax.legend(handles=handles, fontsize=7.6, loc="lower right",
              frameon=True, framealpha=0.95, edgecolor="#cbd5e1",
              borderpad=0.5, handlelength=1.1,
              title=None)

    fig.tight_layout(pad=0.18)
    fig.savefig(OUT_PDF, bbox_inches="tight", pad_inches=0.02)
    fig.savefig(OUT_PNG, dpi=200, bbox_inches="tight", pad_inches=0.02)
    print("wrote", OUT_PDF, "and", OUT_PNG)


if __name__ == "__main__":
    main()
