#!/usr/bin/env python3
"""Render the dashboard's "Step Transition Taxonomy" distribution chart
(10 navigation labels + 4 R->T evidence labels, Correct vs Incorrect macro-%)
as standalone paper-ready PDFs, one per framework, plus PNG previews.

Data source: the live dashboard analysis cache, so the numbers match the
dashboard EXACTLY (see scripts/dashboard/backend/api/routes/analysis.py
:_compute_transitions / _macro_label_dist). No DB / recompute needed.
"""
import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

CACHE = "/home/nn/SOTA-agents/RCAgentEval/scripts/dashboard/analysis_cache.json"
OUT = os.path.dirname(os.path.abspath(__file__))

# canonical RQ2 order (figures/render_rq2_move_stream.py): two ThinkDepth.ai peers first
EXPS = [
    ("thinkdepthai-qwen3.5-plus",      "td_qwen",    r"ThinkDepth.ai$\cdot$Qwen"),
    ("thinkdepthai-qwen3.5-plus-12cat-coding", "td_qwen_treatment", r"ThinkDepth.ai$\cdot$Qwen$^{\mathrm{treat}}$"),
    ("thinkdepthai-claude-sonnet-4.6", "td_sonnet",  r"ThinkDepth.ai$\cdot$Sonnet"),
    ("claudecode-qwen3.5-plus",        "claudecode", "ClaudeCode"),
    ("aiq-qwen3.5-plus",               "aiq",        "AIQ"),
    ("taskweaver-qwen3.5-plus",        "taskweaver", "TaskWeaver"),
]

# Paper colours: consistent with the RQ1 figure palette.
C_COR, C_INC = "#4878CF", "#E0585B"
SEP = r"$\mathbf{-\!-\!-\ R\!\rightarrow\!T\ -\!-\!-}$"

cache = json.load(open(CACHE))


def render(exp_id, key, disp, ax=None, with_legend=True, with_title=True):
    d = cache[f"transitions|{exp_id}"]["experiments"][0]
    dist = d["label_distribution"]                       # LABEL_ORDER, len 14
    rt_start = next(i for i, it in enumerate(dist) if it["label"].startswith("rt:"))

    # build rows top->bottom, inserting a separator before the rt: block
    rows = []  # (label, cor_pct, inc_pct, is_sep)
    for i, it in enumerate(dist):
        if i == rt_start:
            rows.append((SEP, 0.0, 0.0, True))
        rows.append((it["label"], it["correct_pct"] * 100, it["incorrect_pct"] * 100, False))

    n = len(rows)
    xpos = list(range(n))                  # left -> right (transposed: labels on x)
    w = 0.38

    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=(6.6, 2.2))

    for (lab, cv, iv, sep), x in zip(rows, xpos):
        if sep:
            ax.axvline(x, color="#cbd5e1", lw=0.8, dashes=(2, 2), zorder=1)
            continue
        ax.bar(x - w/2, cv, width=w, color=C_COR, zorder=3)
        ax.bar(x + w/2, iv, width=w, color=C_INC, zorder=3)

    # x labels (transposed: the 14 transition labels run along x; the R->T
    # separator is shown as a dashed vertical rule with a blank tick)
    ax.set_xticks(xpos)
    ax.set_xticklabels([("" if r[3] else r[0]) for r in rows], fontsize=5.9,
                       rotation=40, ha="right", rotation_mode="anchor", color="#475569")
    ax.set_xlim(-0.7, n - 0.3)

    # y axis as percent
    ymax = max((max(cv, iv) for _, cv, iv, s in rows if not s), default=10)
    ax.set_ylim(0, ymax * 1.06)
    ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}%"))
    ax.tick_params(axis="y", labelsize=6.2, colors="#64748b", length=2)
    ax.grid(axis="y", color="#e2e8f0", lw=0.6, dashes=(3, 3), zorder=0)
    for sp in ["top", "right", "bottom"]:
        ax.spines[sp].set_visible(False)
    ax.spines["left"].set_color("#cbd5e1")

    if with_title:
        ax.set_title(f"{disp}  "
                     r"$\;$" + f"(correct {d['correct_count']}, incorrect {d['incorrect_count']})",
                     fontsize=7.6, loc="left", color="#1e293b", pad=4)

    if with_legend:
        ax.legend(handles=[Line2D([0], [0], color=C_COR, lw=5, label="Correct"),
                           Line2D([0], [0], color=C_INC, lw=5, label="Incorrect")],
                  fontsize=6.2, loc="upper center", ncol=2, frameon=False, handlelength=1.2,
                  labelspacing=0.25, borderaxespad=0.2, columnspacing=1.2)

    if standalone:
        fig.tight_layout(pad=0.4)
        fig.savefig(f"{OUT}/rq2_transition_dist_{key}.pdf", bbox_inches="tight", facecolor="white")
        fig.savefig(f"{OUT}/rq2_transition_dist_{key}.png", dpi=200, bbox_inches="tight", facecolor="white")
        plt.close(fig)
        print(f"wrote rq2_transition_dist_{key}.pdf/.png  (correct {d['correct_count']}, incorrect {d['incorrect_count']})")


# ThinkDepth.ai cross-base / intervention comparison: qwen baseline vs sonnet-base run
# vs qwen TREATMENT, ALL cases (all_pct), no correct/incorrect split. Colours match
# the RQ2 move-stream figure (qwen blue, sonnet orange, treatment green) -- NOT the
# red/green of the cor/inc splits.
CMP = [
    ("thinkdepthai-qwen3.5-plus",      r"ThinkDepth.ai$\cdot$Qwen",   "#1f77b4"),
    ("thinkdepthai-claude-sonnet-4.6", r"ThinkDepth.ai$\cdot$Sonnet", "#ff7f0e"),
    ("thinkdepthai-qwen3.5-plus-12cat-coding", r"ThinkDepth.ai$\cdot$Qwen$^{\mathrm{treat}}$", "#2E7D32"),
]


def render_compare(key="td_compare", ax=None, with_legend=True, with_title=True):
    series = []  # (disp, color, dist)
    for exp_id, disp, color in CMP:
        d = cache[f"transitions|{exp_id}"]["experiments"][0]
        n = d["correct_count"] + d["incorrect_count"]
        series.append((f"{disp}", color, d["label_distribution"], n))
    dist0 = series[0][2]
    rt_start = next(i for i, it in enumerate(dist0) if it["label"].startswith("rt:"))

    # rows: (label, [pct per series], is_sep)
    rows = []
    for i, it in enumerate(dist0):
        if i == rt_start:
            rows.append((SEP, [0.0] * len(series), True))
        vals = [s[2][i]["all_pct"] * 100 for s in series]
        rows.append((it["label"], vals, False))

    n = len(rows)
    ypos = list(range(n))[::-1]
    k = len(series)                                   # generalize to N overlaid series
    bh = 0.78 / k
    offsets = [((k - 1) / 2 - i) * bh for i in range(k)]   # + at top, - at bottom

    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=(4.3, 3.5))

    for (lab, vals, sep), y in zip(rows, ypos):
        if sep:
            continue
        for i, s in enumerate(series):
            ax.barh(y + offsets[i], vals[i], height=bh, color=s[1], zorder=3)

    ax.set_yticks(ypos)
    ax.set_yticklabels([r[0] for r in rows], fontsize=6.6)
    for tick, r in zip(ax.get_yticklabels(), rows):
        if r[2]:
            tick.set_color("#94a3b8"); tick.set_fontsize(6.0)
        else:
            tick.set_color("#475569")
    ax.set_ylim(-0.7, n - 0.3)

    xmax = max((max(v) for _, v, s in rows if not s), default=10)
    ax.set_xlim(0, xmax * 1.06)
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}%"))
    ax.tick_params(axis="x", labelsize=6.2, colors="#64748b", length=2)
    ax.grid(axis="x", color="#e2e8f0", lw=0.6, dashes=(3, 3), zorder=0)
    for sp in ["top", "right", "left"]:
        ax.spines[sp].set_visible(False)
    ax.spines["bottom"].set_color("#cbd5e1")

    if with_title:
        ax.set_title("ThinkDepth.ai: Qwen vs. Sonnet vs. Qwen$^{\\mathrm{treat}}$  "
                     f"(all {series[0][3]} cases each)",
                     fontsize=7.6, loc="left", color="#1e293b", pad=4)
    if with_legend:
        ax.legend(handles=[Line2D([0], [0], color=s[1], lw=5, label=s[0]) for s in series],
                  fontsize=6.2, loc="lower right", frameon=False, handlelength=1.2,
                  labelspacing=0.25, borderaxespad=0.2)

    if standalone:
        fig.tight_layout(pad=0.4)
        fig.savefig(f"{OUT}/rq2_transition_{key}.pdf", bbox_inches="tight", facecolor="white")
        fig.savefig(f"{OUT}/rq2_transition_{key}.png", dpi=200, bbox_inches="tight", facecolor="white")
        plt.close(fig)
        print(f"wrote rq2_transition_{key}.pdf/.png  (qwen vs sonnet, all cases)")


if __name__ == "__main__":
    import sys
    sel = sys.argv[1:] if len(sys.argv) > 1 else [k for _, k, _ in EXPS] + ["td_compare"]
    for exp_id, key, disp in EXPS:
        if key in sel:
            render(exp_id, key, disp)
    if "td_compare" in sel:
        render_compare()
