#!/usr/bin/env python3
"""Assemble the two-panel RQ2 transition grid (qwen baseline + sonnet base) into
figures/rq2_transition_grid.pdf, reusing the per-arm panel renderer in
render_rq2_transition_dist.py. The qwen-treatment panel was removed together with
the same-dataset treatment experiment.

  python figures/render_rq2_transition_grid.py
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from render_rq2_transition_dist import render  # noqa: E402

PANELS = [
    ("thinkdepthai-qwen3.5-plus",      "td_qwen",   r"ThinkDepth.ai$\cdot$Qwen"),
    ("thinkdepthai-claude-sonnet-4.6", "td_sonnet", r"ThinkDepth.ai$\cdot$Sonnet"),
]


def main():
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 2.7))
    for i, (eid, key, disp) in enumerate(PANELS):
        render(eid, key, disp, ax=axes[i], with_legend=(i == 0), with_title=True)
    fig.tight_layout(pad=0.6)
    fig.savefig(f"{HERE}/rq2_transition_grid.pdf", bbox_inches="tight", facecolor="white")
    fig.savefig(f"{HERE}/rq2_transition_grid.png", dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote rq2_transition_grid.pdf/.png (2 panels: qwen baseline, sonnet)")


if __name__ == "__main__":
    main()
