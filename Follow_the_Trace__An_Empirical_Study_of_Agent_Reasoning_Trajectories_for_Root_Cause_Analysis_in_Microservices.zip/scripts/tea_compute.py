#!/usr/bin/env python3
"""Compute RQ5 ablation numbers (accuracy + per-incident reasoning budget) from TEA.db.

Reproduces the values in tables/treat_ablation.tex:
  - single-run Acc@1 (mean +/- sample sd over the 5 runs)
  - pass@3 / pass@5 (mean over C(5,k) run-combinations of the union pass rate)
  - effective rounds per incident (assistant messages issuing >=1 tool call)
  - total LLM tokens per incident (mean, and the 5-run total in Mtok)

Usage:
    python scripts/tea_compute.py [/path/to/TEA.db]
Default DB path: /Users/luqisheng/workspace/python_code/Aiops/TEA/TEA.db
"""
import sys
import json
import sqlite3
import statistics
import itertools

DEFAULT_DB = "/Users/luqisheng/workspace/python_code/Aiops/TEA/TEA.db"
ARMS = ["baseline", "Only_Teacher", "Only_Explorer", "Full_Tea"]

# doubao-seed-2.0-pro-260215 official list price, Volcano Engine (<=32K input tier):
# CNY 3.2 / 1M input, CNY 16 / 1M output. Converted to USD at FX_CNY_PER_USD.
# Source: volcengine.com/product/doubao (2026-02-15 checkpoint). Region-consistent
# with the qwen3.5-plus Beijing price used for RQ1.
FX_CNY_PER_USD = 7.2
PRICE_IN_PER_M = 3.2 / FX_CNY_PER_USD   # ~= $0.444 / 1M input
PRICE_OUT_PER_M = 16.0 / FX_CNY_PER_USD  # ~= $2.222 / 1M output
N_INCIDENTS = 400  # one evaluation run covers the 400 AIOps 2025 incidents


def effective_rounds(trajectory):
    """Count assistant messages that issue at least one tool call (the paper's rounds)."""
    try:
        msgs = json.loads(trajectory)
    except (json.JSONDecodeError, TypeError):
        return None
    return sum(
        1
        for m in msgs
        if isinstance(m, dict) and m.get("role") == "assistant" and m.get("tool_calls")
    )


def pass_at_k(per_uuid_runs, runs, k):
    """Mean over all C(len(runs), k) combinations of the union pass rate."""
    uuids = list(per_uuid_runs)
    n = len(uuids)
    vals = []
    for combo in itertools.combinations(runs, k):
        solved = sum(
            1 for u in uuids if any(per_uuid_runs[u].get(r, 0) for r in combo)
        )
        vals.append(100.0 * solved / n)
    return statistics.mean(vals)


def main():
    db = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_DB
    con = sqlite3.connect(db)
    cur = con.cursor()

    header = (
        f"{'arm':14s} {'Acc@1':>12s} {'pass@3':>7s} {'pass@5':>7s} "
        f"{'rds':>6s} {'ktok':>7s} {'Mtok':>7s} {'$/case':>7s}"
    )
    print(header)
    print("-" * len(header))

    for arm in ARMS:
        cur.execute(
            "SELECT uuid, run, correct, scored, trajectory, "
            "json_extract(usage,'$.total_tokens'), "
            "json_extract(usage,'$.prompt_tokens'), "
            "json_extract(usage,'$.completion_tokens') FROM tea_runs WHERE arm=?",
            (arm,),
        )
        per_uuid = {}
        rounds, tokens, prompt_tok, compl_tok = [], [], [], []
        for uuid, run, correct, scored, traj, tok, ptok, ctok in cur.fetchall():
            per_uuid.setdefault(uuid, {})[run] = correct or 0
            r = effective_rounds(traj)
            if r is not None:
                rounds.append(r)
            if tok is not None:
                tokens.append(tok)
            if ptok is not None:
                prompt_tok.append(ptok)
            if ctok is not None:
                compl_tok.append(ctok)

        runs = sorted({r for u in per_uuid.values() for r in u})
        n = len(per_uuid)
        per_run_acc = [
            100.0 * sum(per_uuid[u].get(r, 0) for u in per_uuid) / n for r in runs
        ]
        acc_mean = statistics.mean(per_run_acc)
        acc_sd = statistics.stdev(per_run_acc)  # sample sd (n-1), matches the paper
        p3 = pass_at_k(per_uuid, runs, 3)
        p5 = pass_at_k(per_uuid, runs, 5)

        # Mean USD cost per incident, from per-incident input/output tokens at list price.
        cost_per_incident = (
            statistics.mean(prompt_tok) * PRICE_IN_PER_M
            + statistics.mean(compl_tok) * PRICE_OUT_PER_M
        ) / 1e6

        print(
            f"{arm:14s} {acc_mean:6.1f}+-{acc_sd:4.1f} {p3:7.1f} {p5:7.1f} "
            f"{statistics.mean(rounds):6.1f} {statistics.mean(tokens)/1e3:7.1f} "
            f"{sum(tokens)/1e6:7.1f} {cost_per_incident:7.3f}"
        )

    con.close()


if __name__ == "__main__":
    main()
